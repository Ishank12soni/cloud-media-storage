const crypto = require("crypto");
const path = require("path");
const supabase = require("../config/supabase");

const BUCKET = "cloudbox-files";

function sanitizeFileName(name) {
  return name
    .replace(/[\/\\?%*:|"<>]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 180);
}

function createStoragePath(userId, folderId, originalName) {
  const extension = path.extname(originalName);
  const baseName = path.basename(originalName, extension);

  const safeBaseName = sanitizeFileName(baseName) || "file";

  const uniqueId = crypto.randomUUID();

  const folderPart = folderId || "root";

  return `${userId}/${folderPart}/${uniqueId}-${safeBaseName}${extension}`;
}


/* ============================================
   UPLOAD FILE
============================================ */

async function uploadFile(req, res) {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: "Authentication required",
      });
    }

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No file uploaded",
      });
    }

    const userId = req.user.id;

    const folderId =
      req.body.folderId &&
      req.body.folderId !== "null" &&
      req.body.folderId !== "undefined" &&
      req.body.folderId !== ""
        ? req.body.folderId
        : null;

    const originalName = req.file.originalname;

    const storagePath = createStoragePath(
      userId,
      folderId,
      originalName
    );

    const {
      data: uploadData,
      error: uploadError,
    } = await supabase.storage
      .from(BUCKET)
      .upload(storagePath, req.file.buffer, {
        contentType: req.file.mimetype,
        upsert: false,
      });

    if (uploadError) {
      console.error("STORAGE UPLOAD ERROR:", uploadError);

      return res.status(500).json({
        success: false,
        message: uploadError.message,
      });
    }

    const {
      data: fileRecord,
      error: dbError,
    } = await supabase
      .from("files")
      .insert({
        user_id: userId,
        folder_id: folderId,
        name: originalName,
        original_name: originalName,
        storage_path: uploadData.path,
        mime_type: req.file.mimetype,
        size_bytes: req.file.size,
      })
      .select()
      .single();

    if (dbError) {
      console.error("FILE DATABASE ERROR:", dbError);

      // Remove storage object if DB insertion fails
      await supabase.storage
        .from(BUCKET)
        .remove([storagePath]);

      return res.status(500).json({
        success: false,
        message: dbError.message,
      });
    }

    return res.status(201).json({
      success: true,
      message: "File uploaded successfully",
      file: fileRecord,
    });
  } catch (error) {
    console.error("UPLOAD FILE ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to upload file",
    });
  }
}


/* ============================================
   GET FILES
============================================ */

async function getFiles(req, res) {
  try {
    const userId = req.user.id;

    const folderId =
      req.query.folderId &&
      req.query.folderId !== "null" &&
      req.query.folderId !== "undefined" &&
      req.query.folderId !== ""
        ? req.query.folderId
        : null;

    let query = supabase
      .from("files")
      .select("*")
      .eq("user_id", userId)
      .is("deleted_at", null);

    if (folderId) {
      query = query.eq("folder_id", folderId);
    } else {
      query = query.is("folder_id", null);
    }

    const {
      data,
      error,
    } = await query.order("created_at", {
      ascending: false,
    });

    if (error) {
      console.error("GET FILES ERROR:", error);

      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.json({
      success: true,
      files: data || [],
    });
  } catch (error) {
    console.error("GET FILES ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to load files",
    });
  }
}


/* ============================================
   DOWNLOAD FILE
============================================ */

async function downloadFile(req, res) {
  try {
    const userId = req.user.id;
    const fileId = req.params.id;

    const {
      data: file,
      error: fileError,
    } = await supabase
      .from("files")
      .select("*")
      .eq("id", fileId)
      .eq("user_id", userId)
      .is("deleted_at", null)
      .single();

    if (fileError || !file) {
      return res.status(404).json({
        success: false,
        message: "File not found",
      });
    }

    const {
      data: signedData,
      error: signedError,
    } = await supabase.storage
      .from(BUCKET)
      .createSignedUrl(
        file.storage_path,
        60,
        {
          download: file.original_name,
        }
      );

    if (signedError) {
      console.error("SIGNED URL ERROR:", signedError);

      return res.status(500).json({
        success: false,
        message: signedError.message,
      });
    }

    return res.json({
      success: true,
      url: signedData.signedUrl,
    });
  } catch (error) {
    console.error("DOWNLOAD FILE ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to generate download link",
    });
  }
}


/* ============================================
   RENAME FILE
============================================ */

async function renameFile(req, res) {
  try {
    const userId = req.user.id;
    const fileId = req.params.id;

    const name = sanitizeFileName(
      String(req.body.name || "")
    );

    if (!name) {
      return res.status(400).json({
        success: false,
        message: "File name is required",
      });
    }

    const {
      data,
      error,
    } = await supabase
      .from("files")
      .update({
        name,
        updated_at: new Date().toISOString(),
      })
      .eq("id", fileId)
      .eq("user_id", userId)
      .is("deleted_at", null)
      .select()
      .single();

    if (error || !data) {
      return res.status(404).json({
        success: false,
        message: error?.message || "File not found",
      });
    }

    return res.json({
      success: true,
      message: "File renamed successfully",
      file: data,
    });
  } catch (error) {
    console.error("RENAME FILE ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to rename file",
    });
  }
}


/* ============================================
   MOVE FILE
============================================ */

async function moveFile(req, res) {
  try {
    const userId = req.user.id;
    const fileId = req.params.id;

    const folderId =
      req.body.folderId &&
      req.body.folderId !== "null" &&
      req.body.folderId !== ""
        ? req.body.folderId
        : null;

    const {
      data,
      error,
    } = await supabase
      .from("files")
      .update({
        folder_id: folderId,
        updated_at: new Date().toISOString(),
      })
      .eq("id", fileId)
      .eq("user_id", userId)
      .is("deleted_at", null)
      .select()
      .single();

    if (error || !data) {
      return res.status(404).json({
        success: false,
        message: error?.message || "File not found",
      });
    }

    return res.json({
      success: true,
      message: "File moved successfully",
      file: data,
    });
  } catch (error) {
    console.error("MOVE FILE ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to move file",
    });
  }
}


/* ============================================
   TRASH FILE
============================================ */

async function deleteFile(req, res) {
  try {
    const userId = req.user.id;
    const fileId = req.params.id;

    const {
      data,
      error,
    } = await supabase
      .from("files")
      .update({
        deleted_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", fileId)
      .eq("user_id", userId)
      .is("deleted_at", null)
      .select()
      .single();

    if (error || !data) {
      return res.status(404).json({
        success: false,
        message: error?.message || "File not found",
      });
    }

    return res.json({
      success: true,
      message: "File moved to trash",
      file: data,
    });
  } catch (error) {
    console.error("DELETE FILE ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to move file to trash",
    });
  }
}


module.exports = {
  uploadFile,
  getFiles,
  downloadFile,
  renameFile,
  moveFile,
  deleteFile,
};