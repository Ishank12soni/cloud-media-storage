const supabase = require("../config/supabase");

async function getFolders(req, res) {
  try {
    const parentId = req.query.parentId || null;

    let query = supabase
      .from("folders")
      .select(
        "id, user_id, parent_id, name, created_at, updated_at, deleted_at"
      )
      .eq("user_id", req.user.id)
      .is("deleted_at", null)
      .order("name", { ascending: true });

    if (parentId) {
      query = query.eq("parent_id", parentId);
    } else {
      query = query.is("parent_id", null);
    }

    const { data, error } = await query;

    if (error) {
      console.error("GET FOLDERS ERROR:", error);

      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.json({
      success: true,
      folders: data || [],
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Unable to load folders",
    });
  }
}


async function createFolder(req, res) {
  try {
    const { name, parentId } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({
        success: false,
        message: "Folder name is required",
      });
    }

    const { data, error } = await supabase
      .from("folders")
      .insert({
        user_id: req.user.id,
        parent_id: parentId || null,
        name: name.trim(),
      })
      .select()
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(201).json({
      success: true,
      folder: data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to create folder",
    });
  }
}


async function renameFolder(req, res) {
  try {
    const { id } = req.params;
    const { name } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({
        success: false,
        message: "Folder name is required",
      });
    }

    const { data, error } = await supabase
      .from("folders")
      .update({
        name: name.trim(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .eq("user_id", req.user.id)
      .is("deleted_at", null)
      .select()
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.json({
      success: true,
      folder: data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to rename folder",
    });
  }
}


async function deleteFolder(req, res) {
  try {
    const { id } = req.params;

    const { data, error } = await supabase
      .from("folders")
      .update({
        deleted_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .eq("user_id", req.user.id)
      .is("deleted_at", null)
      .select()
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.json({
      success: true,
      folder: data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to delete folder",
    });
  }
}


module.exports = {
  getFolders,
  createFolder,
  renameFolder,
  deleteFolder,
};