const supabase = require("../config/supabase");

async function getProfile(req, res) {
  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", req.user.id)
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.json({
      success: true,
      profile: data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to load profile",
    });
  }
}


async function updateProfile(req, res) {
  try {
    const { fullName } = req.body;

    if (!fullName || !fullName.trim()) {
      return res.status(400).json({
        success: false,
        message: "Name is required",
      });
    }

    const { data, error } = await supabase
      .from("profiles")
      .update({
        full_name: fullName.trim(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", req.user.id)
      .select()
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    await supabase.auth.admin.updateUserById(
      req.user.id,
      {
        user_metadata: {
          full_name: fullName.trim(),
        },
      }
    );

    res.json({
      success: true,
      profile: data,
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Unable to update profile",
    });
  }
}


async function changePassword(req, res) {
  try {
    const { password } = req.body;

    if (!password || password.length < 6) {
      return res.status(400).json({
        success: false,
        message: "Password must contain at least 6 characters",
      });
    }

    const { error } =
      await supabase.auth.admin.updateUserById(
        req.user.id,
        {
          password,
        }
      );

    if (error) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    res.json({
      success: true,
      message: "Password updated successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to change password",
    });
  }
}


module.exports = {
  getProfile,
  updateProfile,
  changePassword,
};