const crypto = require("crypto");
const supabase = require("../config/supabase");

async function createShare(req, res) {
  try {
    const {
      itemType,
      itemId,
      email,
      permission = "viewer",
    } = req.body;

    if (!itemType || !itemId || !email) {
      return res.status(400).json({
        success: false,
        message: "Item and email are required",
      });
    }

    const { data, error } = await supabase
      .from("shares")
      .insert({
        owner_id: req.user.id,
        item_type: itemType,
        item_id: itemId,
        shared_with_email: email.toLowerCase().trim(),
        permission,
      })
      .select()
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.status(201).json({
      success: true,
      share: data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to share item",
    });
  }
}


async function getShares(req, res) {
  try {
    const { itemType, itemId } = req.query;

    const { data, error } = await supabase
      .from("shares")
      .select("*")
      .eq("owner_id", req.user.id)
      .eq("item_type", itemType)
      .eq("item_id", itemId)
      .order("created_at", { ascending: false });

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.json({
      success: true,
      shares: data || [],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to load shares",
    });
  }
}


async function deleteShare(req, res) {
  try {
    const { id } = req.params;

    const { error } = await supabase
      .from("shares")
      .delete()
      .eq("id", id)
      .eq("owner_id", req.user.id);

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.json({
      success: true,
      message: "Access revoked",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to revoke access",
    });
  }
}


async function createPublicLink(req, res) {
  try {
    const {
      itemType,
      itemId,
      expiresAt,
    } = req.body;

    const token = crypto
      .randomBytes(32)
      .toString("hex");

    const { data, error } = await supabase
      .from("link_shares")
      .insert({
        owner_id: req.user.id,
        item_type: itemType,
        item_id: itemId,
        token,
        expires_at: expiresAt || null,
      })
      .select()
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.status(201).json({
      success: true,
      link: data,
      token,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to create public link",
    });
  }
}


async function deletePublicLink(req, res) {
  try {
    const { id } = req.params;

    const { error } = await supabase
      .from("link_shares")
      .delete()
      .eq("id", id)
      .eq("owner_id", req.user.id);

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.json({
      success: true,
      message: "Public link deleted",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to delete public link",
    });
  }
}


module.exports = {
  createShare,
  getShares,
  deleteShare,
  createPublicLink,
  deletePublicLink,
};