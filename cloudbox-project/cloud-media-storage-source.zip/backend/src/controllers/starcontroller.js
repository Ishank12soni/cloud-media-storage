const supabase = require("../config/supabase");

async function getStars(req, res) {
  try {
    const { data, error } = await supabase
      .from("stars")
      .select("*")
      .eq("user_id", req.user.id)
      .order("created_at", { ascending: false });

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.json({
      success: true,
      stars: data || [],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to load starred items",
    });
  }
}


async function addStar(req, res) {
  try {
    const { itemType, itemId } = req.body;

    if (!itemType || !itemId) {
      return res.status(400).json({
        success: false,
        message: "Item information is required",
      });
    }

    const { data, error } = await supabase
      .from("stars")
      .upsert(
        {
          user_id: req.user.id,
          item_type: itemType,
          item_id: itemId,
        },
        {
          onConflict: "user_id,item_type,item_id",
        }
      )
      .select()
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.json({
      success: true,
      star: data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to star item",
    });
  }
}


async function removeStar(req, res) {
  try {
    const { itemType, itemId } = req.body;

    const { error } = await supabase
      .from("stars")
      .delete()
      .eq("user_id", req.user.id)
      .eq("item_type", itemType)
      .eq("item_id", itemId);

    if (error) {
      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    res.json({
      success: true,
      message: "Removed from starred",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Unable to remove star",
    });
  }
}


module.exports = {
  getStars,
  addStar,
  removeStar,
};