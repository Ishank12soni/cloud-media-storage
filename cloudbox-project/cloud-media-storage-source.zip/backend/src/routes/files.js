const express = require("express");
const multer = require("multer");

const auth = require("../middleware/auth");

const {
  uploadFile,
  getFiles,
  downloadFile,
  renameFile,
  moveFile,
  deleteFile,
} = require("../controllers/fileController");

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),

  limits: {
    fileSize: 50 * 1024 * 1024,
  },
});


router.get(
  "/",
  auth,
  getFiles
);


router.post(
  "/upload",
  auth,
  upload.single("file"),
  uploadFile
);


router.get(
  "/:id/download",
  auth,
  downloadFile
);


router.patch(
  "/:id/rename",
  auth,
  renameFile
);


router.patch(
  "/:id/move",
  auth,
  moveFile
);


router.delete(
  "/:id",
  auth,
  deleteFile
);


module.exports = router;