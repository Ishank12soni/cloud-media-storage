const express = require("express");
const supabase = require("../config/supabase");
const auth = require("../middleware/auth");

const router = express.Router();


// GET FOLDERS
// /api/folders
// /api/folders?parentId=UUID
router.get("/", auth, async (req, res) => {
  try {
    const { parentId } = req.query;

    let query = supabase
      .from("folders")
      .select("*")
      .eq("user_id", req.user.id)
      .is("deleted_at", null)
      .order("name", { ascending: true });

    if (parentId) {
      query = query.eq("parent_id", parentId);
    } else {
      query = query.is("parent_id", null);
    }

    const { data, error } = await query;

    if (error) {
      console.error("GET FOLDERS ERROR:", error);

      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(200).json({
      success: true,
      folders: data || [],
    });
  } catch (error) {
    console.error("GET FOLDERS ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to load folders",
    });
  }
});


// GET SINGLE FOLDER
router.get("/:id", auth, async (req, res) => {
  try {
    const { id } = req.params;

    const { data, error } = await supabase
      .from("folders")
      .select("*")
      .eq("id", id)
      .eq("user_id", req.user.id)
      .is("deleted_at", null)
      .single();

    if (error) {
      return res.status(404).json({
        success: false,
        message: "Folder not found",
      });
    }

    return res.status(200).json({
      success: true,
      folder: data,
    });
  } catch (error) {
    console.error("GET FOLDER ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to load folder",
    });
  }
});


// CREATE FOLDER
router.post("/", auth, async (req, res) => {
  try {
    const { name, parentId = null } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({
        success: false,
        message: "Folder name is required",
      });
    }

    const folderName = name.trim();

    const { data: existingFolder } = await supabase
      .from("folders")
      .select("id")
      .eq("user_id", req.user.id)
      .eq("name", folderName)
      .eq("parent_id", parentId)
      .is("deleted_at", null)
      .maybeSingle();

    if (existingFolder) {
      return res.status(409).json({
        success: false,
        message: "A folder with this name already exists",
      });
    }

    const { data, error } = await supabase
      .from("folders")
      .insert({
        user_id: req.user.id,
        parent_id: parentId,
        name: folderName,
      })
      .select()
      .single();

    if (error) {
      console.error("CREATE FOLDER ERROR:", error);

      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(201).json({
      success: true,
      message: "Folder created successfully",
      folder: data,
    });
  } catch (error) {
    console.error("CREATE FOLDER ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to create folder",
    });
  }
});


// RENAME FOLDER
router.patch("/:id", auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, parentId } = req.body;

    const updateData = {};

    if (name !== undefined) {
      if (!name.trim()) {
        return res.status(400).json({
          success: false,
          message: "Folder name cannot be empty",
        });
      }

      updateData.name = name.trim();
    }

    if (parentId !== undefined) {
      updateData.parent_id = parentId;
    }

    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({
        success: false,
        message: "No changes provided",
      });
    }

    const { data, error } = await supabase
      .from("folders")
      .update(updateData)
      .eq("id", id)
      .eq("user_id", req.user.id)
      .is("deleted_at", null)
      .select()
      .single();

    if (error || !data) {
      return res.status(404).json({
        success: false,
        message: "Folder not found or update failed",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Folder updated successfully",
      folder: data,
    });
  } catch (error) {
    console.error("UPDATE FOLDER ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update folder",
    });
  }
});


// DELETE FOLDER
// Soft delete
router.delete("/:id", auth, async (req, res) => {
  try {
    const { id } = req.params;

    const { data, error } = await supabase
      .from("folders")
      .update({
        deleted_at: new Date().toISOString(),
      })
      .eq("id", id)
      .eq("user_id", req.user.id)
      .is("deleted_at", null)
      .select()
      .single();

    if (error || !data) {
      return res.status(404).json({
        success: false,
        message: "Folder not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Folder moved to trash",
      folder: data,
    });
  } catch (error) {
    console.error("DELETE FOLDER ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to delete folder",
    });
  }
});


// RESTORE FOLDER
router.patch("/:id/restore", auth, async (req, res) => {
  try {
    const { id } = req.params;

    const { data, error } = await supabase
      .from("folders")
      .update({
        deleted_at: null,
      })
      .eq("id", id)
      .eq("user_id", req.user.id)
      .select()
      .single();

    if (error || !data) {
      return res.status(404).json({
        success: false,
        message: "Folder not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Folder restored successfully",
      folder: data,
    });
  } catch (error) {
    console.error("RESTORE FOLDER ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to restore folder",
    });
  }
});


module.exports = router;