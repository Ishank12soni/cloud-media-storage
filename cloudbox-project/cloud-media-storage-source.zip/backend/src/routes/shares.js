const express = require("express");

const authenticate = require("../middleware/auth");

const {
  createShare,
  getShares,
  deleteShare,
  createPublicLink,
  deletePublicLink,
} = require("../controllers/shareController");

const router = express.Router();

router.use(authenticate);

router.post("/", createShare);
router.get("/", getShares);
router.delete("/:id", deleteShare);

router.post("/public", createPublicLink);
router.delete("/public/:id", deletePublicLink);

module.exports = router;