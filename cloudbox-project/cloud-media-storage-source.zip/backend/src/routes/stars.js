const express = require("express");

const authenticate = require("../middleware/auth");

const {
  getStars,
  addStar,
  removeStar,
} = require("../controllers/starController");

const router = express.Router();

router.use(authenticate);

router.get("/", getStars);
router.post("/", addStar);
router.delete("/", removeStar);

module.exports = router;