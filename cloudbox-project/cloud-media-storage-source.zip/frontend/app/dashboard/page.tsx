"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabase";

type Folder = {
  id: string;
  owner_id: string;
  parent_id: string | null;
  name: string;
  created_at: string;
  updated_at: string;
};

type Breadcrumb = {
  id: string | null;
  name: string;
};

const API_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:5001";

export default function DashboardPage() {
  const router = useRouter();

  const [folders, setFolders] = useState<Folder[]>([]);
  const [breadcrumbs, setBreadcrumbs] = useState<Breadcrumb[]>([
    {
      id: null,
      name: "My Drive",
    },
  ]);

  const [currentFolderId, setCurrentFolderId] = useState<string | null>(
    null
  );

  const [userEmail, setUserEmail] = useState("");
  const [userName, setUserName] = useState("");

  const [loading, setLoading] = useState(true);
  const [folderLoading, setFolderLoading] = useState(false);

  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");

  const [editingFolder, setEditingFolder] = useState<Folder | null>(null);
  const [editFolderName, setEditFolderName] = useState("");

  const [errorMessage, setErrorMessage] = useState("");

  const [darkMode, setDarkMode] = useState(false);

  /*
  |--------------------------------------------------------------------------
  | CHECK AUTHENTICATION
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    checkUser();
  }, []);

  async function checkUser() {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.replace("/signin");
        return;
      }

      setUserEmail(user.email || "");

      const metadata = user.user_metadata || {};

      setUserName(
        metadata.full_name ||
          metadata.name ||
          user.email?.split("@")[0] ||
          "User"
      );

      await loadFolders(null);
    } catch (error) {
      console.error(error);
      router.replace("/signin");
    } finally {
      setLoading(false);
    }
  }

  /*
  |--------------------------------------------------------------------------
  | LOAD FOLDERS
  |--------------------------------------------------------------------------
  */

  async function loadFolders(parentId: string | null) {
    try {
      setFolderLoading(true);
      setErrorMessage("");

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        router.replace("/signin");
        return;
      }

      let url = `${API_URL}/api/folders`;

      if (parentId) {
        url += `?parentId=${encodeURIComponent(parentId)}`;
      }

      const response = await fetch(url, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Unable to load folders");
      }

      setFolders(data.folders || []);
    } catch (error: any) {
      console.error("LOAD FOLDERS ERROR:", error);

      setErrorMessage(
        error.message || "Unable to load folders"
      );
    } finally {
      setFolderLoading(false);
    }
  }

  /*
  |--------------------------------------------------------------------------
  | CREATE FOLDER
  |--------------------------------------------------------------------------
  */

  async function createFolder() {
    const cleanName = newFolderName.trim();

    if (!cleanName) {
      setErrorMessage("Please enter a folder name.");
      return;
    }

    try {
      setFolderLoading(true);
      setErrorMessage("");

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        router.replace("/signin");
        return;
      }

      const response = await fetch(`${API_URL}/api/folders`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          name: cleanName,
          parentId: currentFolderId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Unable to create folder");
      }

      setNewFolderName("");
      setShowNewFolder(false);

      await loadFolders(currentFolderId);
    } catch (error: any) {
      console.error("CREATE FOLDER ERROR:", error);

      setErrorMessage(
        error.message || "Unable to create folder"
      );
    } finally {
      setFolderLoading(false);
    }
  }

  /*
  |--------------------------------------------------------------------------
  | RENAME FOLDER
  |--------------------------------------------------------------------------
  */

  async function renameFolder() {
    const cleanName = editFolderName.trim();

    if (!editingFolder) {
      return;
    }

    if (!cleanName) {
      setErrorMessage("Folder name cannot be empty.");
      return;
    }

    try {
      setFolderLoading(true);
      setErrorMessage("");

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        router.replace("/signin");
        return;
      }

      const response = await fetch(
        `${API_URL}/api/folders/${editingFolder.id}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            name: cleanName,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Unable to rename folder");
      }

      setEditingFolder(null);
      setEditFolderName("");

      await loadFolders(currentFolderId);
    } catch (error: any) {
      console.error("RENAME FOLDER ERROR:", error);

      setErrorMessage(
        error.message || "Unable to rename folder"
      );
    } finally {
      setFolderLoading(false);
    }
  }

  /*
  |--------------------------------------------------------------------------
  | DELETE FOLDER
  |--------------------------------------------------------------------------
  */

  async function deleteFolder(folder: Folder) {
    const confirmed = window.confirm(
      `Delete "${folder.name}"?\n\nThis folder must be empty before it can be deleted.`
    );

    if (!confirmed) {
      return;
    }

    try {
      setFolderLoading(true);
      setErrorMessage("");

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        router.replace("/signin");
        return;
      }

      const response = await fetch(
        `${API_URL}/api/folders/${folder.id}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Unable to delete folder");
      }

      await loadFolders(currentFolderId);
    } catch (error: any) {
      console.error("DELETE FOLDER ERROR:", error);

      setErrorMessage(
        error.message || "Unable to delete folder"
      );
    } finally {
      setFolderLoading(false);
    }
  }

  /*
  |--------------------------------------------------------------------------
  | OPEN FOLDER
  |--------------------------------------------------------------------------
  */

  async function openFolder(folder: Folder) {
    setCurrentFolderId(folder.id);

    setBreadcrumbs((previous) => [
      ...previous,
      {
        id: folder.id,
        name: folder.name,
      },
    ]);

    await loadFolders(folder.id);
  }

  /*
  |--------------------------------------------------------------------------
  | BREADCRUMB NAVIGATION
  |--------------------------------------------------------------------------
  */

  async function navigateBreadcrumb(
    breadcrumb: Breadcrumb,
    index: number
  ) {
    setCurrentFolderId(breadcrumb.id);

    setBreadcrumbs((previous) => previous.slice(0, index + 1));

    await loadFolders(breadcrumb.id);
  }

  /*
  |--------------------------------------------------------------------------
  | LOGOUT
  |--------------------------------------------------------------------------
  */

  async function handleLogout() {
    await supabase.auth.signOut();
    router.replace("/signin");
  }

  /*
  |--------------------------------------------------------------------------
  | FORMAT DATE
  |--------------------------------------------------------------------------
  */

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  }

  /*
  |--------------------------------------------------------------------------
  | LOADING
  |--------------------------------------------------------------------------
  */

  if (loading) {
    return (
      <main className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-blue-600 border-t-transparent" />
          <p className="text-slate-600">
            Loading your CloudBox...
          </p>
        </div>
      </main>
    );
  }

  /*
  |--------------------------------------------------------------------------
  | UI
  |--------------------------------------------------------------------------
  */

  return (
    <main
      className={
        darkMode
          ? "min-h-screen bg-black text-white transition-colors"
          : "min-h-screen bg-slate-50 text-slate-900 transition-colors"
      }
    >
      {/* HEADER */}

      <header
        className={
          darkMode
            ? "border-b border-slate-800 bg-black"
            : "border-b border-slate-200 bg-white"
        }
      >
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
          {/* LOGO */}

          <button
            onClick={() => {
              setCurrentFolderId(null);
              setBreadcrumbs([
                {
                  id: null,
                  name: "My Drive",
                },
              ]);
              loadFolders(null);
            }}
            className="flex items-center gap-3"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-xl text-white shadow-md">
              ☁
            </div>

            <span
              className={
                darkMode
                  ? "text-xl font-bold text-white"
                  : "text-xl font-bold text-slate-900"
              }
            >
              CloudBox
            </span>
          </button>

          {/* HEADER RIGHT */}

          <div className="flex items-center gap-4">
            {/* THEME */}

            <button
              onClick={() => setDarkMode(!darkMode)}
              className={
                darkMode
                  ? "rounded-lg border border-slate-700 px-4 py-2 text-sm hover:bg-slate-900"
                  : "rounded-lg border border-slate-300 px-4 py-2 text-sm hover:bg-slate-100"
              }
            >
              {darkMode ? "☀ Light" : "◐ Dark"}
            </button>

            {/* USER */}

            <div className="hidden text-right sm:block">
              <p className="text-sm font-semibold">
                {userName}
              </p>

              <p
                className={
                  darkMode
                    ? "text-xs text-slate-400"
                    : "text-xs text-slate-500"
                }
              >
                {userEmail}
              </p>
            </div>

            <button
              onClick={handleLogout}
              className="rounded-lg border border-red-200 px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* MAIN LAYOUT */}

      <div className="mx-auto flex max-w-7xl">
        {/* SIDEBAR */}

        <aside
          className={
            darkMode
              ? "hidden min-h-[calc(100vh-80px)] w-64 border-r border-slate-800 bg-black p-5 md:block"
              : "hidden min-h-[calc(100vh-80px)] w-64 border-r border-slate-200 bg-white p-5 md:block"
          }
        >
          <button
            onClick={() => {
              setCurrentFolderId(null);
              setBreadcrumbs([
                {
                  id: null,
                  name: "My Drive",
                },
              ]);
              loadFolders(null);
            }}
            className="mb-6 flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 py-3 font-semibold text-white shadow-md hover:bg-blue-700"
          >
            <span className="text-xl">+</span>
            New
          </button>

          <nav className="space-y-1">
            <button
              onClick={() => {
                setCurrentFolderId(null);
                setBreadcrumbs([
                  {
                    id: null,
                    name: "My Drive",
                  },
                ]);
                loadFolders(null);
              }}
              className="flex w-full items-center gap-3 rounded-lg bg-blue-50 px-4 py-3 text-left font-medium text-blue-700"
            >
              📁
              <span>My Drive</span>
            </button>

            <button className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-left text-slate-600 hover:bg-slate-100">
              🕘
              <span>Recent</span>
            </button>

            <button className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-left text-slate-600 hover:bg-slate-100">
              ⭐
              <span>Starred</span>
            </button>

            <button className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-left text-slate-600 hover:bg-slate-100">
              👥
              <span>Shared with me</span>
            </button>

            <button className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-left text-slate-600 hover:bg-slate-100">
              🗑️
              <span>Trash</span>
            </button>
          </nav>

          <div className="mt-10">
            <p
              className={
                darkMode
                  ? "mb-3 text-xs font-semibold uppercase tracking-wider text-slate-500"
                  : "mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400"
              }
            >
              Storage
            </p>

            <div
              className={
                darkMode
                  ? "rounded-xl bg-slate-900 p-4"
                  : "rounded-xl bg-slate-50 p-4"
              }
            >
              <div className="mb-2 flex justify-between text-xs">
                <span>Used</span>
                <span>0 GB / 15 GB</span>
              </div>

              <div className="h-2 overflow-hidden rounded-full bg-slate-200">
                <div className="h-full w-[3%] rounded-full bg-blue-600" />
              </div>

              <p className="mt-3 text-xs text-slate-500">
                Your storage usage will appear here.
              </p>
            </div>
          </div>
        </aside>

        {/* CONTENT */}

        <section className="min-w-0 flex-1 p-6 md:p-8">
          {/* TOP */}

          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold">
                My Drive
              </h1>

              <p
                className={
                  darkMode
                    ? "mt-1 text-slate-400"
                    : "mt-1 text-slate-500"
                }
              >
                Store and organize your files securely.
              </p>
            </div>

            <button
              onClick={() => {
                setShowNewFolder(true);
                setNewFolderName("");
                setErrorMessage("");
              }}
              className="rounded-xl bg-blue-600 px-5 py-3 font-semibold text-white shadow-md hover:bg-blue-700"
            >
              + New Folder
            </button>
          </div>

          {/* BREADCRUMBS */}

          <div
            className={
              darkMode
                ? "mb-5 flex flex-wrap items-center gap-2 rounded-xl border border-slate-800 bg-slate-950 px-4 py-3"
                : "mb-5 flex flex-wrap items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3"
            }
          >
            {breadcrumbs.map((breadcrumb, index) => (
              <div
                key={`${breadcrumb.id || "root"}-${index}`}
                className="flex items-center gap-2"
              >
                {index > 0 && (
                  <span className="text-slate-400">
                    /
                  </span>
                )}

                <button
                  onClick={() =>
                    navigateBreadcrumb(
                      breadcrumb,
                      index
                    )
                  }
                  className={
                    index === breadcrumbs.length - 1
                      ? "font-semibold text-slate-900 dark:text-white"
                      : "text-blue-600 hover:underline"
                  }
                >
                  {breadcrumb.name}
                </button>
              </div>
            ))}
          </div>

          {/* ERROR */}

          {errorMessage && (
            <div className="mb-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
              {errorMessage}
            </div>
          )}

          {/* FOLDER AREA */}

          <div
            className={
              darkMode
                ? "rounded-2xl border border-slate-800 bg-slate-950 p-5"
                : "rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"
            }
          >
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                Folders
              </h2>

              {folderLoading && (
                <span className="text-sm text-slate-500">
                  Updating...
                </span>
              )}
            </div>

            {folders.length === 0 ? (
              <div className="flex min-h-[300px] flex-col items-center justify-center text-center">
                <div className="mb-4 text-6xl">
                  📁
                </div>

                <h3 className="text-xl font-semibold">
                  This folder is empty
                </h3>

                <p
                  className={
                    darkMode
                      ? "mt-2 max-w-md text-slate-400"
                      : "mt-2 max-w-md text-slate-500"
                  }
                >
                  Create your first folder to start
                  organizing your cloud files.
                </p>

                <button
                  onClick={() => {
                    setShowNewFolder(true);
                    setNewFolderName("");
                  }}
                  className="mt-5 rounded-lg bg-blue-600 px-5 py-2.5 font-medium text-white hover:bg-blue-700"
                >
                  Create Folder
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {folders.map((folder) => (
                  <div
                    key={folder.id}
                    className={
                      darkMode
                        ? "group rounded-xl border border-slate-800 bg-black p-4 hover:border-blue-500"
                        : "group rounded-xl border border-slate-200 bg-white p-4 hover:border-blue-400 hover:shadow-md"
                    }
                  >
                    <div className="flex items-start justify-between">
                      <button
                        onDoubleClick={() =>
                          openFolder(folder)
                        }
                        onClick={() =>
                          openFolder(folder)
                        }
                        className="flex min-w-0 flex-1 items-center gap-3 text-left"
                      >
                        <span className="text-4xl">
                          📁
                        </span>

                        <div className="min-w-0">
                          <p className="truncate font-semibold">
                            {folder.name}
                          </p>

                          <p className="mt-1 text-xs text-slate-500">
                            {formatDate(
                              folder.created_at
                            )}
                          </p>
                        </div>
                      </button>

                      <div className="ml-2 flex gap-1">
                        <button
                          title="Rename"
                          onClick={() => {
                            setEditingFolder(folder);
                            setEditFolderName(
                              folder.name
                            );
                            setErrorMessage("");
                          }}
                          className="rounded-md p-2 text-slate-500 hover:bg-slate-100 hover:text-blue-600"
                        >
                          ✏️
                        </button>

                        <button
                          title="Delete"
                          onClick={() =>
                            deleteFolder(folder)
                          }
                          className="rounded-md p-2 text-slate-500 hover:bg-red-50 hover:text-red-600"
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* INFO */}

          <div
            className={
              darkMode
                ? "mt-6 rounded-xl border border-blue-900 bg-blue-950/30 p-4 text-sm text-blue-200"
                : "mt-6 rounded-xl border border-blue-100 bg-blue-50 p-4 text-sm text-blue-800"
            }
          >
            <strong>CloudBox My Drive:</strong>{" "}
            Folder management is now connected to your
            Supabase database. File upload and sharing
            will be added in the next stages.
          </div>
        </section>
      </div>

      {/* CREATE FOLDER MODAL */}

      {showNewFolder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div
            className={
              darkMode
                ? "w-full max-w-md rounded-2xl border border-slate-700 bg-slate-950 p-6"
                : "w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"
            }
          >
            <h2 className="text-xl font-bold">
              Create New Folder
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Enter a name for your new folder.
            </p>

            <input
              autoFocus
              value={newFolderName}
              onChange={(e) =>
                setNewFolderName(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  createFolder();
                }

                if (e.key === "Escape") {
                  setShowNewFolder(false);
                }
              }}
              placeholder="Folder name"
              maxLength={100}
              className={
                darkMode
                  ? "mt-5 w-full rounded-xl border border-slate-700 bg-black px-4 py-3 text-white outline-none focus:border-blue-500"
                  : "mt-5 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
              }
            />

            <div className="mt-5 flex justify-end gap-3">
              <button
                onClick={() =>
                  setShowNewFolder(false)
                }
                className="rounded-lg border border-slate-300 px-4 py-2 font-medium"
              >
                Cancel
              </button>

              <button
                onClick={createFolder}
                className="rounded-lg bg-blue-600 px-5 py-2 font-medium text-white hover:bg-blue-700"
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RENAME MODAL */}

      {editingFolder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div
            className={
              darkMode
                ? "w-full max-w-md rounded-2xl border border-slate-700 bg-slate-950 p-6"
                : "w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"
            }
          >
            <h2 className="text-xl font-bold">
              Rename Folder
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Change the folder name.
            </p>

            <input
              autoFocus
              value={editFolderName}
              onChange={(e) =>
                setEditFolderName(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  renameFolder();
                }

                if (e.key === "Escape") {
                  setEditingFolder(null);
                }
              }}
              maxLength={100}
              className={
                darkMode
                  ? "mt-5 w-full rounded-xl border border-slate-700 bg-black px-4 py-3 text-white outline-none focus:border-blue-500"
                  : "mt-5 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
              }
            />

            <div className="mt-5 flex justify-end gap-3">
              <button
                onClick={() =>
                  setEditingFolder(null)
                }
                className="rounded-lg border border-slate-300 px-4 py-2 font-medium"
              >
                Cancel
              </button>

              <button
                onClick={renameFolder}
                className="rounded-lg bg-blue-600 px-5 py-2 font-medium text-white hover:bg-blue-700"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}